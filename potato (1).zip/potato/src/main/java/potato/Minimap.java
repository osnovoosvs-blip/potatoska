package potato;

import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class Minimap {
    private static final int MAX = 128;
    private static final int[] colors = new int[MAX * MAX];
    private static final int[] heights = new int[MAX * MAX];
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    private record Line(String text, int color) {}

    public static void update(MinecraftClient mc) {
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null) return;
        Config c = Config.I;
        int D = MathHelper.clamp(c.mapSize, 32, MAX), R = D / 2;
        int originX = p.getBlockX() - R, originZ = p.getBlockZ() - R;
        boolean ceiling = w.getDimension().hasCeiling();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int row = 0; row < D; row++) {
            for (int col = 0; col < D; col++) {
                int i = row * D + col;
                int x = originX + col, z = originZ + row;
                colors[i] = 0;
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
                if (ceiling) top = Math.min(top, p.getBlockY() + 4);
                for (int y = top; y > w.getBottomY(); y--) {
                    m.set(x, y, z);
                    BlockState s = w.getBlockState(m);
                    if (s.isAir()) continue;
                    MapColor mc2 = s.getMapColor(w, m);
                    if (mc2 == MapColor.CLEAR) continue;
                    int rgb = mc2.color;
                    double k = 1.0;
                    if (c.mapRelief && row > 0) {
                        int cmp = Integer.compare(y, heights[i - D]);
                        k = cmp > 0 ? 1.15 : cmp < 0 ? 0.8 : 1.0;
                    }
                    int r = Math.min(255, (int) (((rgb >> 16) & 255) * k));
                    int g = Math.min(255, (int) (((rgb >> 8) & 255) * k));
                    int b = Math.min(255, (int) ((rgb & 255) * k));
                    colors[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
                    heights[i] = y;
                    break;
                }
            }
        }
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        Config c = Config.I;
        if (p == null || mc.world == null || mc.options.hudHidden || !c.showMap) return;

        int D = MathHelper.clamp(c.mapSize, 32, MAX), R = D / 2;
        int S = MathHelper.clamp(c.mapScale, 1, 4);
        int size = D * S;
        int W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight();
        boolean right = c.mapCorner == 0 || c.mapCorner == 2;
        boolean bottom = c.mapCorner >= 2;

        // text lines
        double px = p.getX(), pz = p.getZ();
        String dim = mc.world.getRegistryKey().getValue().toString();
        List<Line> lines = new ArrayList<>();
        if (c.showCoords) lines.add(new Line(p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ(), 0xFFFFFFFF));
        if (c.showStatus) lines.add(new Line("Aim+Trigger: " + (CombatAssist.enabled ? "ON" : "OFF"),
                CombatAssist.enabled ? 0xFF55FF55 : 0xFFAAAAAA));
        if (c.listLength > 0) {
            Waypoints.LIST.stream()
                    .filter(w -> w.visible && w.dim.equals(dim))
                    .sorted(Comparator.comparingDouble(w -> sq(w.x + 0.5 - px, w.z + 0.5 - pz)))
                    .limit(c.listLength)
                    .forEach(w -> {
                        double dx = w.x + 0.5 - px, dz = w.z + 0.5 - pz;
                        int dist = (int) Math.sqrt(dx * dx + dz * dz);
                        double ang = (Math.toDegrees(Math.atan2(dx, -dz)) + 360) % 360;
                        lines.add(new Line(w.name + " " + dist + "m " + DIRS[(int) Math.round(ang / 45.0) % 8],
                                0xFF000000 | w.color));
                    });
        }

        int ox = right ? W - size - 8 : 8;
        int oy = bottom ? H - size - 8 : 8;
        if (bottom) oy -= lines.size() * 10 + 3;
        ctx.fill(ox - 1, oy - 1, ox + size + 1, oy + size + 1, 0xFF000000);

        for (int row = 0; row < D; row++) {
            int col = 0;
            while (col < D) {
                int col0 = colors[row * D + col];
                int s = col;
                while (col < D && colors[row * D + col] == col0) col++;
                if (col0 != 0) ctx.fill(ox + s * S, oy + row * S, ox + col * S, oy + (row + 1) * S, col0);
            }
        }

        if (c.mapWaypoints) {
            int d = MathHelper.clamp(c.dotSize, 3, 9) / 2;
            for (Waypoints.Waypoint wp : Waypoints.LIST) {
                if (!wp.visible || !wp.dim.equals(dim)) continue;
                double dx = MathHelper.clamp(wp.x + 0.5 - px, -R + 2, R - 2);
                double dz = MathHelper.clamp(wp.z + 0.5 - pz, -R + 2, R - 2);
                int sx = ox + (int) ((dx + R) * S);
                int sz = oy + (int) ((dz + R) * S);
                ctx.fill(sx - d - 1, sz - d - 1, sx + d + 2, sz + d + 2, 0xFF000000);
                ctx.fill(sx - d, sz - d, sx + d + 1, sz + d + 1, 0xFF000000 | wp.color);
            }
        }

        int cx = ox + size / 2, cy = oy + size / 2;
        ctx.fill(cx - 2, cy - 2, cx + 3, cy + 3, 0xFF000000);
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer, "N", cx - 2, oy + 2, 0xFFFFFFFF);

        int ty = bottom ? oy + size + 4 : oy + size + 4;
        if (bottom) ty = oy + size + 4;
        for (Line l : lines) {
            ctx.drawTextWithShadow(mc.textRenderer, l.text(), ox, ty, l.color());
            ty += 10;
        }
    }

    private static double sq(double a, double b) { return a * a + b * b; }
}
