package potato;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Aimbot + triggerbot as ONE module: the trigger only fires once the aim is on target. */
public final class CombatAssist {
    public static boolean enabled = false;
    private static int onTargetTicks = 0;

    private static float[] angles(Vec3d eye, LivingEntity t, Config c) {
        Box bb = t.getBoundingBox();
        double ay = bb.minY + t.getHeight() * (c.aimHeight / 100.0);
        double dx = t.getX() - eye.x, dy = ay - eye.y, dz = t.getZ() - eye.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{yaw, pitch};
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        Config c = Config.I;
        if (!enabled || p == null || mc.world == null || mc.currentScreen != null
                || mc.interactionManager == null) { onTargetTicks = 0; return; }

        Vec3d eye = p.getEyePos();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity t) || t == p || !t.isAlive() || t.isSpectator()) continue;
            boolean valid = (c.targetHostile && t instanceof Monster)
                    || (c.targetPlayers && t instanceof PlayerEntity)
                    || (c.targetPassive && t instanceof PassiveEntity);
            if (!valid) continue;
            double d = p.distanceTo(t);
            if (d > c.aimRange) continue;
            if (c.needLineOfSight && !p.canSee(t)) continue;
            if (c.aimFov < 360) {
                float[] a = angles(eye, t, c);
                if (Math.abs(MathHelper.wrapDegrees(a[0] - p.getYaw())) > c.aimFov / 2
                        || Math.abs(a[1] - p.getPitch()) > c.aimFov / 2) continue;
            }
            if (d < bestDist) { bestDist = d; best = t; }
        }
        if (best == null) { onTargetTicks = 0; return; }

        // --- aim ---
        float[] a = angles(eye, best, c);
        float speed = (float) c.aimSpeed;
        float dYaw = MathHelper.wrapDegrees(a[0] - p.getYaw());
        float dPitch = a[1] - p.getPitch();
        p.setYaw(p.getYaw() + MathHelper.clamp(dYaw, -speed, speed));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dPitch, -speed, speed), -90f, 90f));

        // --- trigger ---
        double reach = Math.min(p.getEntityInteractionRange(), c.triggerReach);
        Vec3d end = eye.add(p.getRotationVec(1.0f).multiply(reach));
        Box hit = best.getBoundingBox().expand(best.getTargetingMargin());
        boolean onTarget = hit.contains(eye) || hit.raycast(eye, end).isPresent();
        if (!onTarget) { onTargetTicks = 0; return; }
        if (p.getAttackCooldownProgress(0.5f) >= c.triggerCharge / 100.0) {
            if (++onTargetTicks > c.triggerDelay) {
                mc.interactionManager.attackEntity(p, best);
                p.swingHand(Hand.MAIN_HAND);
                onTargetTicks = 0;
            }
        }
    }
}
