package potato;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** All mod settings. Saved to config/potato_config.json. */
public final class Config {
    // ---- Aim + Trigger ----
    public boolean targetHostile = true;
    public boolean targetPlayers = false;
    public boolean targetPassive = false;
    public boolean needLineOfSight = true;
    public double aimRange = 6.0;      // blocks
    public double aimSpeed = 25;       // degrees per tick
    public double aimHeight = 75;      // % of target height (0 feet .. 100 top of head)
    public double aimFov = 360;        // degrees, 360 = no limit
    public double triggerCharge = 100; // % attack cooldown needed to hit
    public double triggerDelay = 0;    // ticks the crosshair must stay on target
    public double triggerReach = 6.0;  // max hit distance (capped by vanilla reach)

    // ---- Minimap ----
    public boolean showMap = true;
    public boolean showCoords = true;
    public boolean showStatus = true;
    public boolean mapWaypoints = true;
    public boolean mapRelief = true;
    public int mapSize = 64;     // blocks across (32..128)
    public int mapScale = 2;     // pixels per block
    public int mapCorner = 0;    // 0 TR, 1 TL, 2 BR, 3 BL
    public int mapInterval = 10; // ticks between map refreshes
    public int listLength = 5;   // waypoint list lines under the map

    // ---- Waypoints ----
    public boolean worldLabels = true;
    public boolean labelName = true;
    public boolean labelDistance = true;
    public double defaultHeight = 2.0; // label height above the waypoint for new waypoints
    public double labelMaxDist = 0;    // 0 = unlimited
    public int dotSize = 5;

    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("potato_config.json");

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            try (Reader r = Files.newBufferedReader(FILE)) {
                Config c = GSON.fromJson(r, Config.class);
                if (c != null) I = c;
            }
        } catch (Exception e) {
            PotatoClient.LOGGER.error("Failed to load config", e);
        }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(I, w);
        } catch (Exception e) {
            PotatoClient.LOGGER.error("Failed to save config", e);
        }
    }
}
