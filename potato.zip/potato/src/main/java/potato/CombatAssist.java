package potato;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Aimbot + triggerbot as ONE module: the trigger only fires once the aim is locked on. */
public final class CombatAssist {
    public static boolean enabled = false;

    // --- settings ---
    public static boolean TARGET_PLAYERS = false; // hostile mobs only by default
    public static double AIM_RANGE = 6.0;         // start aiming within this many blocks
    public static float AIM_SPEED = 25f;          // max degrees turned per tick

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!enabled || p == null || mc.world == null || mc.currentScreen != null
                || mc.interactionManager == null) return;

        double reach = p.getEntityInteractionRange();

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity t) || t == p || !t.isAlive() || t.isSpectator()) continue;
            boolean valid = t instanceof HostileEntity || (TARGET_PLAYERS && t instanceof PlayerEntity);
            if (!valid) continue;
            double d = p.distanceTo(t);
            if (d > AIM_RANGE || !p.canSee(t)) continue;
            if (d < bestDist) { bestDist = d; best = t; }
        }
        if (best == null) return;

        // --- aim ---
        Vec3d eye = p.getEyePos();
        Box bb = best.getBoundingBox();
        Vec3d aim = new Vec3d(best.getX(), bb.minY + best.getHeight() * 0.75, best.getZ());
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx))) - 90f;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        float dYaw = MathHelper.wrapDegrees(targetYaw - p.getYaw());
        float dPitch = targetPitch - p.getPitch();
        p.setYaw(p.getYaw() + MathHelper.clamp(dYaw, -AIM_SPEED, AIM_SPEED));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dPitch, -AIM_SPEED, AIM_SPEED), -90f, 90f));

        // --- trigger (only when the crosshair is really on the target) ---
        Vec3d end = eye.add(p.getRotationVec(1.0f).multiply(reach));
        Box hit = bb.expand(best.getTargetingMargin());
        boolean onTarget = hit.contains(eye) || hit.raycast(eye, end).isPresent();
        if (onTarget && p.getAttackCooldownProgress(0.5f) >= 1.0f) {
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
