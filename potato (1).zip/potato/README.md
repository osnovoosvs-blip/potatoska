# Potato (Fabric 1.21.11, client-only)
Keys: K = waypoint at your position, R = toggle Aim+Trigger, O = settings.
Commands: /wp add <name> [x y z], /wp del <name>, /wp list, /wp aim, /wp settings
Config: config/potato_config.json, config/potato_waypoints.json
Build: see GitHub Actions workflow in .github/workflows/build.yml
