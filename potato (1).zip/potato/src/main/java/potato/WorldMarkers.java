package potato;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Draws waypoint labels over the world view (HUD projection, no world-render hooks). */
public final class WorldMarkers {
    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        Config c = Config.I;
        if (p == null || mc.world == null || mc.options.hudHidden || !c.worldLabels) return;

        int W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight();
        double yaw = Math.toRadians(p.getYaw()), pitch = Math.toRadians(p.getPitch());
        double cp = Math.cos(pitch);
        double fx = -Math.sin(yaw) * cp, fy = -Math.sin(pitch), fz = Math.cos(yaw) * cp;
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        Vec3d eye = p.getEyePos();
        double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double aspect = (double) W / H;
        String dim = mc.world.getRegistryKey().getValue().toString();

        for (Waypoints.Waypoint wp : Waypoints.LIST) {
            if (!wp.visible || !wp.inWorld || !wp.dim.equals(dim)) continue;
            double dx = wp.x + 0.5 - eye.x;
            double dy = wp.y + 0.5 + wp.height - eye.y;
            double dz = wp.z + 0.5 - eye.z;
            double dist = Math.sqrt(dx * dx + (wp.y - eye.y) * (wp.y - eye.y) + dz * dz);
            if (c.labelMaxDist > 0 && dist > c.labelMaxDist) continue;

            double cx = dx * rx + dy * ry + dz * rz;
            double cy = dx * ux + dy * uy + dz * uz;
            double cz = dx * fx + dy * fy + dz * fz;
            if (cz < 0.1) continue;
            int sx = (int) (W / 2.0 + (cx / cz) / (tan * aspect) * (W / 2.0));
            int sy = (int) (H / 2.0 - (cy / cz) / tan * (H / 2.0));
            if (sx < 0 || sx > W || sy < 0 || sy > H) continue;

            int s = Math.max(3, Math.min(9, c.dotSize)) / 2;
            int col = 0xFF000000 | wp.color;
            ctx.fill(sx - s - 1, sy - s - 1, sx + s + 2, sy + s + 2, 0xFF000000);
            ctx.fill(sx - s, sy - s, sx + s + 1, sy + s + 1, col);

            String label = "";
            if (c.labelName) label += wp.name;
            if (c.labelDistance) label += (label.isEmpty() ? "" : " ") + (int) dist + "m";
            if (!label.isEmpty())
                ctx.drawCenteredTextWithShadow(mc.textRenderer, label, sx, sy - s - 12, col);
        }
    }
}
