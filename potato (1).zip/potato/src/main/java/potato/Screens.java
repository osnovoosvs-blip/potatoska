package potato;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;

abstract class BaseScreen extends Screen {
    protected final Screen parent;

    BaseScreen(String title, Screen parent) {
        super(Text.literal(title));
        this.parent = parent;
    }

    protected int col(int c) { return width / 2 + (c == 0 ? -155 : 5); }
    protected int row(int r) { return 32 + r * 24; }

    protected void done() {
        addDrawableChild(Ui.button(width / 2 - 100, height - 28, 200, "Готово", this::close));
    }

    @Override public void close() { client.setScreen(parent); }
    @Override public void removed() { Config.save(); Waypoints.save(); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFFFF);
    }
}

/** Main settings menu. */
final class SettingsScreen extends BaseScreen {
    SettingsScreen(Screen parent) { super("Potato — настройки", parent); }

    @Override
    protected void init() {
        int x = width / 2 - 100;
        addDrawableChild(Ui.button(x, row(0), 200, "Аим и триггер", () -> client.setScreen(new AimScreen(this))));
        addDrawableChild(Ui.button(x, row(1), 200, "Карта", () -> client.setScreen(new MapScreen(this))));
        addDrawableChild(Ui.button(x, row(2), 200, "Метки", () -> client.setScreen(new WaypointsScreen(this))));
        done();
    }
}

final class AimScreen extends BaseScreen {
    AimScreen(Screen parent) { super("Аим и триггер", parent); }

    @Override
    protected void init() {
        Config c = Config.I;
        int w = 150;
        addDrawableChild(Ui.toggle(col(0), row(0), w, "Аим+Триггер", () -> CombatAssist.enabled, v -> CombatAssist.enabled = v));
        addDrawableChild(Ui.toggle(col(1), row(0), w, "Нужна видимость", () -> c.needLineOfSight, v -> c.needLineOfSight = v));
        addDrawableChild(Ui.toggle(col(0), row(1), w, "Враждебные", () -> c.targetHostile, v -> c.targetHostile = v));
        addDrawableChild(Ui.toggle(col(1), row(1), w, "Игроки", () -> c.targetPlayers, v -> c.targetPlayers = v));
        addDrawableChild(Ui.toggle(col(0), row(2), w, "Мирные", () -> c.targetPassive, v -> c.targetPassive = v));
        addDrawableChild(new Slider(col(1), row(2), w, "Дальность наводки", 2, 12, 0.5, c.aimRange, v -> c.aimRange = v));
        addDrawableChild(new Slider(col(0), row(3), w, "Скорость (°/тик)", 1, 60, 1, c.aimSpeed, v -> c.aimSpeed = v));
        addDrawableChild(new Slider(col(1), row(3), w, "Точка (% роста)", 0, 100, 5, c.aimHeight, v -> c.aimHeight = v));
        addDrawableChild(new Slider(col(0), row(4), w, "Угол (360=всё)", 10, 360, 10, c.aimFov, v -> c.aimFov = v));
        addDrawableChild(new Slider(col(1), row(4), w, "Заряд удара %", 50, 100, 5, c.triggerCharge, v -> c.triggerCharge = v));
        addDrawableChild(new Slider(col(0), row(5), w, "Задержка (тики)", 0, 10, 1, c.triggerDelay, v -> c.triggerDelay = v));
        addDrawableChild(new Slider(col(1), row(5), w, "Дальность удара", 2, 6, 0.5, c.triggerReach, v -> c.triggerReach = v));
        done();
    }
}

final class MapScreen extends BaseScreen {
    MapScreen(Screen parent) { super("Карта", parent); }

    @Override
    protected void init() {
        Config c = Config.I;
        int w = 150;
        String[] corners = {"Справа сверху", "Слева сверху", "Справа снизу", "Слева снизу"};
        addDrawableChild(Ui.toggle(col(0), row(0), w, "Карта", () -> c.showMap, v -> c.showMap = v));
        addDrawableChild(Ui.cycle(col(1), row(0), w, "Позиция", corners, () -> c.mapCorner, v -> c.mapCorner = v));
        addDrawableChild(new Slider(col(0), row(1), w, "Размер (блоки)", 32, 128, 16, c.mapSize, v -> c.mapSize = (int) v));
        addDrawableChild(new Slider(col(1), row(1), w, "Масштаб (px)", 1, 4, 1, c.mapScale, v -> c.mapScale = (int) v));
        addDrawableChild(Ui.toggle(col(0), row(2), w, "Координаты", () -> c.showCoords, v -> c.showCoords = v));
        addDrawableChild(Ui.toggle(col(1), row(2), w, "Статус аима", () -> c.showStatus, v -> c.showStatus = v));
        addDrawableChild(Ui.toggle(col(0), row(3), w, "Метки на карте", () -> c.mapWaypoints, v -> c.mapWaypoints = v));
        addDrawableChild(Ui.toggle(col(1), row(3), w, "Рельеф", () -> c.mapRelief, v -> c.mapRelief = v));
        addDrawableChild(new Slider(col(0), row(4), w, "Список меток", 0, 10, 1, c.listLength, v -> c.listLength = (int) v));
        addDrawableChild(new Slider(col(1), row(4), w, "Обновление (тики)", 2, 40, 1, c.mapInterval, v -> c.mapInterval = (int) v));
        done();
    }
}

final class WaypointsScreen extends BaseScreen {
    WaypointsScreen(Screen parent) { super("Метки", parent); }

    @Override
    protected void init() {
        Config c = Config.I;
        int w = 150;
        addDrawableChild(Ui.toggle(col(0), row(0), w, "Метки в мире", () -> c.worldLabels, v -> c.worldLabels = v));
        addDrawableChild(Ui.toggle(col(1), row(0), w, "Имя на метке", () -> c.labelName, v -> c.labelName = v));
        addDrawableChild(Ui.toggle(col(0), row(1), w, "Дистанция", () -> c.labelDistance, v -> c.labelDistance = v));
        addDrawableChild(new Slider(col(1), row(1), w, "Размер точки", 3, 9, 2, c.dotSize, v -> c.dotSize = (int) v));
        addDrawableChild(new Slider(col(0), row(2), w, "Высота новых", -5, 50, 1, c.defaultHeight, v -> c.defaultHeight = v));
        addDrawableChild(new Slider(col(1), row(2), w, "Макс. дист. (0=∞)", 0, 2000, 50, c.labelMaxDist, v -> c.labelMaxDist = v));
        addDrawableChild(Ui.button(col(0), row(3), w, "Добавить здесь", () -> {
            ClientPlayerEntity p = client.player;
            if (p == null) return;
            Waypoints.add("WP" + (Waypoints.LIST.size() + 1), p.getBlockX(), p.getBlockY(), p.getBlockZ(),
                    client.world.getRegistryKey().getValue().toString());
        }));
        addDrawableChild(Ui.button(col(1), row(3), w, "Изменить метки...", () -> client.setScreen(new WaypointListScreen(this))));
        done();
    }
}

final class WaypointListScreen extends BaseScreen {
    private static final int PER_PAGE = 6;
    private int page = 0;

    WaypointListScreen(Screen parent) { super("Список меток", parent); }

    @Override
    protected void init() {
        int pages = Math.max(1, (Waypoints.LIST.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        int x = width / 2 - 150;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= Waypoints.LIST.size()) break;
            Waypoints.Waypoint wp = Waypoints.LIST.get(idx);
            Text label = Text.literal(wp.name).styled(s -> s.withColor(wp.color))
                    .append(Text.literal("  " + wp.x + " " + wp.y + " " + wp.z).styled(s -> s.withColor(0xAAAAAA)));
            addDrawableChild(ButtonWidget.builder(label, b -> client.setScreen(new WaypointEditScreen(this, wp)))
                    .dimensions(x, row(i), 300, 20).build());
        }
        addDrawableChild(Ui.button(width / 2 - 100, row(6) + 4, 60, "<", () -> { page--; clearAndInit(); }));
        addDrawableChild(Ui.button(width / 2 + 40, row(6) + 4, 60, ">", () -> { page++; clearAndInit(); }));
        done();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int pages = Math.max(1, (Waypoints.LIST.size() + PER_PAGE - 1) / PER_PAGE);
        ctx.drawCenteredTextWithShadow(textRenderer, (page + 1) + " / " + pages, width / 2, row(6) + 10, 0xFFFFFFFF);
    }
}

final class WaypointEditScreen extends BaseScreen {
    private final Waypoints.Waypoint wp;

    WaypointEditScreen(Screen parent, Waypoints.Waypoint wp) {
        super("Метка: " + wp.name, parent);
        this.wp = wp;
    }

    @Override
    protected void init() {
        int w = 150;
        TextFieldWidget name = new TextFieldWidget(textRenderer, width / 2 - 100, row(0), 200, 20, Text.literal("Имя"));
        name.setMaxLength(32);
        name.setText(wp.name);
        name.setChangedListener(s -> { if (!s.isBlank()) wp.name = s.trim(); });
        addDrawableChild(name);

        addDrawableChild(new Slider(col(0), row(1), w, "Красный", 0, 255, 5, (wp.color >> 16) & 255,
                v -> wp.color = (wp.color & 0x00FFFF) | ((int) v << 16)));
        addDrawableChild(new Slider(col(0), row(2), w, "Зелёный", 0, 255, 5, (wp.color >> 8) & 255,
                v -> wp.color = (wp.color & 0xFF00FF) | ((int) v << 8)));
        addDrawableChild(new Slider(col(0), row(3), w, "Синий", 0, 255, 5, wp.color & 255,
                v -> wp.color = (wp.color & 0xFFFF00) | (int) v));

        addDrawableChild(Ui.toggle(col(1), row(1), w, "Видна", () -> wp.visible, v -> wp.visible = v));
        addDrawableChild(Ui.toggle(col(1), row(2), w, "В мире", () -> wp.inWorld, v -> wp.inWorld = v));
        addDrawableChild(new Slider(col(1), row(3), w, "Высота метки", -10, 100, 1, wp.height, v -> wp.height = v));

        addDrawableChild(Ui.button(col(0), row(4), w, "На мою позицию", () -> {
            ClientPlayerEntity p = client.player;
            if (p == null) return;
            wp.x = p.getBlockX(); wp.y = p.getBlockY(); wp.z = p.getBlockZ();
            wp.dim = client.world.getRegistryKey().getValue().toString();
        }));
        addDrawableChild(Ui.button(col(1), row(4), w, "Удалить", () -> {
            Waypoints.LIST.remove(wp);
            Waypoints.save();
            close();
        }));
        done();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.fill(width / 2 - 100, row(5) + 4, width / 2 + 100, row(5) + 16, 0xFFFFFFFF);
        ctx.fill(width / 2 - 99, row(5) + 5, width / 2 + 99, row(5) + 15, 0xFF000000 | wp.color);
    }
}
