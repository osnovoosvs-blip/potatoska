package potato;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class PotatoClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("potato");
    private int ticks = 0;
    private int autoName = 1;

    @Override
    public void onInitializeClient() {
        Waypoints.load();

        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("potato", "keys"));
        KeyBinding addKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.potato.waypoint", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, cat));
        KeyBinding combatKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.potato.combat", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, cat));

        HudElementRegistry.addLast(Identifier.of("potato", "hud"), (ctx, tick) -> Minimap.render(ctx));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            if (ticks++ % 10 == 0) Minimap.update(mc);
            while (addKey.wasPressed()) {
                String n = "WP" + autoName++;
                addHere(mc, n);
                mc.player.sendMessage(Text.literal("Waypoint added: " + n), true);
            }
            while (combatKey.wasPressed()) {
                CombatAssist.enabled = !CombatAssist.enabled;
                mc.player.sendMessage(Text.literal("Aim+Trigger: " + (CombatAssist.enabled ? "ON" : "OFF")), true);
            }
            CombatAssist.tick(mc);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(literal("wp")
                .then(literal("add").then(argument("name", StringArgumentType.word())
                    .executes(c -> {
                        addHere(c.getSource().getClient(), StringArgumentType.getString(c, "name"));
                        c.getSource().sendFeedback(Text.literal("Waypoint saved at your position"));
                        return 1;
                    })
                    .then(argument("x", IntegerArgumentType.integer())
                    .then(argument("y", IntegerArgumentType.integer())
                    .then(argument("z", IntegerArgumentType.integer())
                        .executes(c -> {
                            Waypoints.add(StringArgumentType.getString(c, "name"),
                                    IntegerArgumentType.getInteger(c, "x"),
                                    IntegerArgumentType.getInteger(c, "y"),
                                    IntegerArgumentType.getInteger(c, "z"),
                                    dim(c.getSource().getClient()));
                            c.getSource().sendFeedback(Text.literal("Waypoint saved"));
                            return 1;
                        }))))))
                .then(literal("del").then(argument("name", StringArgumentType.word())
                    .executes(c -> {
                        boolean ok = Waypoints.remove(StringArgumentType.getString(c, "name"));
                        c.getSource().sendFeedback(Text.literal(ok ? "Removed" : "Not found"));
                        return ok ? 1 : 0;
                    })))
                .then(literal("list").executes(c -> {
                    FabricClientCommandSource s = c.getSource();
                    if (Waypoints.LIST.isEmpty()) s.sendFeedback(Text.literal("No waypoints"));
                    for (Waypoints.Waypoint w : Waypoints.LIST)
                        s.sendFeedback(Text.literal(w.name() + ": " + w.x() + " " + w.y() + " " + w.z() + " [" + w.dim() + "]"));
                    return 1;
                }))
                .then(literal("aim").executes(c -> {
                    CombatAssist.enabled = !CombatAssist.enabled;
                    c.getSource().sendFeedback(Text.literal("Aim+Trigger: " + (CombatAssist.enabled ? "ON" : "OFF")));
                    return 1;
                }))));
    }

    private static String dim(MinecraftClient mc) {
        return mc.world.getRegistryKey().getValue().toString();
    }

    private static void addHere(MinecraftClient mc, String name) {
        Waypoints.add(name, mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ(), dim(mc));
    }
}
