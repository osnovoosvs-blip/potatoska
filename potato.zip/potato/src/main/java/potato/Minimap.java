package potato;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;

import java.util.Comparator;
import java.util.List;

public final class Minimap {
    private static final int D = 64;          // blocks across
    private static final int R = D / 2;
    private static final int SCALE = 2;       // pixels per block
    private static final int[] colors = new int[D * D];
    private static final int[] heights = new int[D * D];
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    private static int originX, originZ;

    /** Rebuild the colour cache (called every few ticks). */
    public static void update(MinecraftClient mc) {
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null) return;
        originX = p.getBlockX() - R;
        originZ = p.getBlockZ() - R;
        boolean ceiling = w.getDimension().hasCeiling();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int row = 0; row < D; row++) {
            for (int col = 0; col < D; col++) {
                int i = row * D + col;
                int x = originX + col, z = originZ + row;
                colors[i] = 0;
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
                if (ceiling) top = Math.min(top, p.getBlockY() + 4);
                for (int y = top; y > w.getBottomY(); y--) {
                    m.set(x, y, z);
                    BlockState s = w.getBlockState(m);
                    if (s.isAir()) continue;
                    MapColor mc2 = s.getMapColor(w, m);
                    if (mc2 == MapColor.CLEAR) continue;
                    int rgb = mc2.color;
                    int cmp = row > 0 ? Integer.compare(y, heights[i - D]) : 0;
                    double k = cmp > 0 ? 1.15 : cmp < 0 ? 0.8 : 1.0;
                    int r = Math.min(255, (int) (((rgb >> 16) & 255) * k));
                    int g = Math.min(255, (int) (((rgb >> 8) & 255) * k));
                    int b = Math.min(255, (int) ((rgb & 255) * k));
                    colors[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
                    heights[i] = y;
                    break;
                }
            }
        }
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.options.hudHidden) return;

        int size = D * SCALE;
        int ox = ctx.getScaledWindowWidth() - size - 8;
        int oy = 8;
        ctx.fill(ox - 1, oy - 1, ox + size + 1, oy + size + 1, 0xFF000000);

        for (int row = 0; row < D; row++) {
            int col = 0;
            while (col < D) {
                int c = colors[row * D + col];
                int s = col;
                while (col < D && colors[row * D + col] == c) col++;
                if (c != 0) ctx.fill(ox + s * SCALE, oy + row * SCALE, ox + col * SCALE, oy + (row + 1) * SCALE, c);
            }
        }

        double px = p.getX(), pz = p.getZ();
        String dim = mc.world.getRegistryKey().getValue().toString();

        // waypoint dots on the map (clamped to the edge)
        for (Waypoints.Waypoint wp : Waypoints.LIST) {
            if (!wp.dim().equals(dim)) continue;
            double dx = MathHelper.clamp(wp.x() + 0.5 - px, -R + 2, R - 2);
            double dz = MathHelper.clamp(wp.z() + 0.5 - pz, -R + 2, R - 2);
            int sx = ox + (int) ((dx + R) * SCALE);
            int sz = oy + (int) ((dz + R) * SCALE);
            ctx.fill(sx - 2, sz - 2, sx + 3, sz + 3, 0xFF000000);
            ctx.fill(sx - 1, sz - 1, sx + 2, sz + 2, 0xFF000000 | wp.color());
        }

        // player marker + north
        int cx = ox + size / 2, cy = oy + size / 2;
        ctx.fill(cx - 2, cy - 2, cx + 3, cy + 3, 0xFF000000);
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer, "N", cx - 2, oy + 2, 0xFFFFFFFF);

        // coordinates
        int ty = oy + size + 4;
        ctx.drawTextWithShadow(mc.textRenderer, p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ(), ox, ty, 0xFFFFFFFF);
        ty += 11;
        ctx.drawTextWithShadow(mc.textRenderer, "Aim+Trigger: " + (CombatAssist.enabled ? "ON" : "OFF"), ox, ty,
                CombatAssist.enabled ? 0xFF55FF55 : 0xFFAAAAAA);
        ty += 11;

        // nearest 5 waypoints in this dimension
        List<Waypoints.Waypoint> near = Waypoints.LIST.stream()
                .filter(w -> w.dim().equals(dim))
                .sorted(Comparator.comparingDouble(w -> sq(w.x() + 0.5 - px, w.z() + 0.5 - pz)))
                .limit(5).toList();
        for (Waypoints.Waypoint wp : near) {
            double dx = wp.x() + 0.5 - px, dz = wp.z() + 0.5 - pz;
            int dist = (int) Math.sqrt(dx * dx + dz * dz);
            double ang = (Math.toDegrees(Math.atan2(dx, -dz)) + 360) % 360;
            String dir = DIRS[(int) Math.round(ang / 45.0) % 8];
            ctx.drawTextWithShadow(mc.textRenderer, wp.name() + " " + dist + "m " + dir, ox, ty, 0xFF000000 | wp.color());
            ty += 10;
        }
    }

    private static double sq(double a, double b) { return a * a + b * b; }
}
