package potato;

import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

final class Ui {
    static ButtonWidget toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
        return ButtonWidget.builder(Text.literal(label + ": " + (get.getAsBoolean() ? "Вкл" : "Выкл")), btn -> {
            boolean n = !get.getAsBoolean();
            set.accept(n);
            btn.setMessage(Text.literal(label + ": " + (n ? "Вкл" : "Выкл")));
        }).dimensions(x, y, w, 20).build();
    }

    static ButtonWidget cycle(int x, int y, int w, String label, String[] opts, IntSupplier get, IntConsumer set) {
        return ButtonWidget.builder(Text.literal(label + ": " + opts[get.getAsInt() % opts.length]), btn -> {
            int n = (get.getAsInt() + 1) % opts.length;
            set.accept(n);
            btn.setMessage(Text.literal(label + ": " + opts[n]));
        }).dimensions(x, y, w, 20).build();
    }

    static ButtonWidget button(int x, int y, int w, String label, Runnable action) {
        return ButtonWidget.builder(Text.literal(label), b -> action.run()).dimensions(x, y, w, 20).build();
    }
}

final class Slider extends SliderWidget {
    private final String label;
    private final double min, max, step;
    private final DoubleConsumer set;

    Slider(int x, int y, int w, String label, double min, double max, double step, double cur, DoubleConsumer set) {
        super(x, y, w, 20, Text.empty(), (MathHelper.clamp(cur, min, max) - min) / (max - min));
        this.label = label; this.min = min; this.max = max; this.step = step; this.set = set;
        updateMessage();
    }

    private double val() {
        double v = min + this.value * (max - min);
        v = Math.round(v / step) * step;
        return MathHelper.clamp(v, min, max);
    }

    @Override
    protected void updateMessage() {
        double v = val();
        String s = step >= 1 ? String.valueOf(Math.round(v)) : String.format(Locale.ROOT, "%.1f", v);
        setMessage(Text.literal(label + ": " + s));
    }

    @Override
    protected void applyValue() { set.accept(val()); }
}
