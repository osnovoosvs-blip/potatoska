# Potato (Fabric 1.21.11, client-only)
Build: install JDK 21, then `gradle wrapper --gradle-version 9.2.1` and `./gradlew build`
(or open the folder in IntelliJ IDEA). Jar: build/libs/potato-1.0.0.jar -> put into mods/ with Fabric API.

Keys: K = waypoint at your position, R = toggle Aim+Trigger (they are one module).
Commands: /wp add <name> [x y z], /wp del <name>, /wp list, /wp aim
Settings (CombatAssist.java): TARGET_PLAYERS, AIM_RANGE, AIM_SPEED.
