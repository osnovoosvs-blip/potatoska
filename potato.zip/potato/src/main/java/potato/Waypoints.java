package potato;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class Waypoints {
    public record Waypoint(String name, int x, int y, int z, String dim, int color) {}

    public static final List<Waypoint> LIST = new ArrayList<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("potato_waypoints.json");
    private static final int[] PALETTE = {0xFF5555, 0x55FF55, 0x5599FF, 0xFFFF55, 0xFF55FF, 0x55FFFF, 0xFFAA00};

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            try (Reader r = Files.newBufferedReader(FILE)) {
                List<Waypoint> l = GSON.fromJson(r, new TypeToken<List<Waypoint>>() {}.getType());
                if (l != null) { LIST.clear(); LIST.addAll(l); }
            }
        } catch (Exception e) {
            PotatoClient.LOGGER.error("Failed to load waypoints", e);
        }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(LIST, w);
        } catch (Exception e) {
            PotatoClient.LOGGER.error("Failed to save waypoints", e);
        }
    }

    public static void add(String name, int x, int y, int z, String dim) {
        LIST.removeIf(w -> w.name().equalsIgnoreCase(name));
        LIST.add(new Waypoint(name, x, y, z, dim, PALETTE[LIST.size() % PALETTE.length]));
        save();
    }

    public static boolean remove(String name) {
        boolean r = LIST.removeIf(w -> w.name().equalsIgnoreCase(name));
        if (r) save();
        return r;
    }
}
